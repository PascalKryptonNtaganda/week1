library(tidyverse)
library(haven)
library(dplyr)

#setting directory
setwd("/Users/pascalntaganda/Downloads/intro-git-PascalKryptonNtaganda-master/OMSBA/raw_data")

#importing data
data <- read_dta("IAHR52FL.dta")

# data characteristics
str(data)
View(data)

#data transformation
# data with columns hhid through shstruc()
data_subset <- select(data, hhid:shstruc) 
View(data_subset)

new_df <- filter(data)
#distribution of the number of listed household members for the entire sample
ggplot(data = data) + 
  geom_histogram(mapping = aes(x=hv009), binwidth = 1) +
  xlab("Number of household members") 

# modifying data for urban households
urban_df <- data %>% 
  select(hhid:hv028) %>% 
  mutate(urban = hv025 == 1)

#factoring urban household data (for program to understand categorical data)

urban_df$urban <- as.factor(urban_df$urban)
str(urban_df)


#boxplot showing distribution of household size by type of urban area
ggplot(data = urban_df) + 
  geom_boxplot(mapping = aes(x=urban)) +
  xlab("Distribution of household size by type of urban area") 


#descriptive statistics


urban_counts <- urban_df %>% 
  group_by(urban) %>% 
  summarise(
    count = n()
  )


